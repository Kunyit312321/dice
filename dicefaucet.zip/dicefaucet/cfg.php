<?php


//Masukan Data User Agent
$user_agent = "Mozilla/5.0 (Linux; Android 7.1.2; Redmi 4A Build/N2G47H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36";
//Maaukan Cookie
$cookie = "faucetpay=84is3j8urlgl40a7dg0k33vo7r;_ga=GA1.2.110942963.1662821239;_gid=GA1.2.201459590.1662821240;__asc=d1f1c11f18327de8bcccde9900d;__auc=d1f1c11f18327de8bcccde9900d;cookieconsent_status=dismiss;remember_me=1505471%3A63072ec1f5b1f2555e8c28b1e87532bf180b8b4e6d73ed197c9854fc9ab7781b%3A078407c9b3846735d7f478e904dd510b25f2029840f61b2f0391875d309c7c8a;session_token=7435e260baa48e7ffbcde78eb8e5c1756e811d550d8ae707bb2322494c72c8ef;dark_mode=1;sc_is_visitor_unique=rx12149426.1662821296.0F90117F0F104F56CBDB14B423027302.1.1.1.1.1.1.1.1.1";
//Masukan Data Dice
$data_dice = "play=true&client_seed=QuPYqZyWtPNZMQ3VjA1PJlFDkCXEwKzcnOcPRLurGnyEaXpyuWSmEwhUPlJRm4bX&coin=TRX&bet_amt=0.00001000&profit=0.00001000&payout=2.00000&winning_chance=47.50&prediction=0";
//Masukan Target Profit
$profit = "10000000";
